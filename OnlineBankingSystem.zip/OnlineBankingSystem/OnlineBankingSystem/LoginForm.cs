﻿using Microsoft.EntityFrameworkCore;
using OnlineBankingSystem.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineBankingSystem
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            comboBoxRole.DataSource = Enum.GetValues(typeof(UserRole));
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            using (var context = new BankDbContext())
            {
                string email = emailTextBox.Text.Trim();
                string password = passwordTextBox.Text.Trim();
                string selectedRole = comboBoxRole.SelectedItem.ToString();
                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Email və şifrəni doldurun!");
                    return;
                }
                UserRole role = (UserRole)comboBoxRole.SelectedIndex;

                var user = context.Users
                    .Where(u => u.Email == email && u.Role == role)
                    .FirstOrDefault();

                if (user == null)
                {
                    MessageBox.Show("İstifadəçi və ya rol tapılmadı!");
                    emailTextBox.Clear();
                    passwordTextBox.Clear();
                    return;
                }
                if (user.Password != password)
                {
                    MessageBox.Show("Şifrə səhvdir!");
                    passwordTextBox.Clear();
                    return;
                }
                if (selectedRole == "Admin")
                {
                    AdminForm adminForm = new AdminForm();
                    adminForm.Show();
                    this.Hide();
                }
                else
                {
                    CustomerForm customerForm = new CustomerForm(user.Id);
                    customerForm.Show();
                    this.Hide();
                }
            }

        }
    }
}
