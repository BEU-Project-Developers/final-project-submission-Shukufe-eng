﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OnlineBankingSystem.Entities;

namespace OnlineBankingSystem
{
    public partial class CustomerForm : Form
    {
        private int _userId;
        public CustomerForm(int userId)
        {
            InitializeComponent();
            _userId = userId;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void LoadUserAccounts()
        {
            using (var context = new BankDbContext())
            {
                var userAccounts = context.UserAccounts
                    .Where(a => a.UserId == _userId)
                    .Select(a => new
                    {
                        a.AccountNumber
                    })
                    .ToList();

                comboBoxAccounts.DataSource = userAccounts;
                comboBoxAccounts.DisplayMember = "AccountNumber";
                comboBoxAccounts.ValueMember = "AccountNumber";
            }
        }

        private void checkBtn_Click(object sender, EventArgs e)
        {
            try
            {
                int accountNumber = (int)comboBoxAccounts.SelectedValue;
                decimal balance;
                using (var context = new BankDbContext())
                {
                    var user = context.UserAccounts.Where(i => i.AccountNumber == accountNumber).FirstOrDefault();
                    balance = user.Balance;
                    balanceLabel.Text = balance + "$";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
           
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            LoadUserAccounts();
        }
        private void withDrawBtn_Click(object sender, EventArgs e)
        {
            decimal amount = decimal.Parse(withdrawAmounttextBox.Text);
            int accountNumber = int.Parse(withDrawAccountNumbertextBox.Text);
            using (var context = new BankDbContext())
            {
                var user = context.UserAccounts.FirstOrDefault(i => i.AccountNumber == accountNumber);
                if (user != null && amount > 0 && amount <= user.Balance)
                {
                    user.Balance -= amount;
                    var transaction = new Transaction
                    {
                        AccountNumber = accountNumber,
                        Amount = amount,
                        TransactionType = "Withdraw",
                        TransactionDate = DateTime.Now
                    };
                    context.Transactions.Add(transaction);
                    context.SaveChanges();

                    MessageBox.Show($"{accountNumber} hesabından {amount}$ çıxarıldı.");
                    withdrawAmounttextBox.Clear();
                    withDrawAccountNumbertextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Düzgün məbləğ daxil edin və ya balans kifayət deyil.");
                }
            }
        }


        private void DepositBtn_Click(object sender, EventArgs e)
        {
            decimal amount = decimal.Parse(depositAmounttextBox.Text);
            int accountNumber = int.Parse(depositAccountNumbertextBox.Text);
            using (var context = new BankDbContext())
            {
                var user = context.UserAccounts.FirstOrDefault(i => i.AccountNumber == accountNumber);
                if (user != null && amount > 0)
                {
                    user.Balance += amount;

                    var transaction = new Transaction
                    {
                        AccountNumber = accountNumber,
                        Amount = amount,
                        TransactionType = "Deposit",
                        TransactionDate = DateTime.Now
                    };

                    context.Transactions.Add(transaction);
                    context.SaveChanges();

                    MessageBox.Show($"{accountNumber} hesabına {amount}$ əlavə edildi.");
                    depositAmounttextBox.Clear();
                    depositAccountNumbertextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Düzgün məbləğ daxil edin və ya hesab tapılmadı.");
                }
            }
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void transferBtn_Click(object sender, EventArgs e)
        {
            int fromAccount = int.Parse(fromTransfertextBox.Text);
            int toAccount = int.Parse(toTransfertextBox.Text);
            decimal amountTransfer = decimal.Parse(amountTransfertextBox.Text);

            using (var context = new BankDbContext())
            {
                var fromAccountUser = context.UserAccounts.FirstOrDefault(i => i.AccountNumber == fromAccount);
                var toAccountUser = context.UserAccounts.FirstOrDefault(i => i.AccountNumber == toAccount);

                if (fromAccountUser != null && toAccountUser != null && amountTransfer > 0 && amountTransfer <= fromAccountUser.Balance)
                {
                    fromAccountUser.Balance -= amountTransfer;
                    toAccountUser.Balance += amountTransfer;
                    var transaction = new Transaction
                    {
                        AccountNumber = fromAccount,
                        TargetAccountNumber = toAccount,
                        Amount = amountTransfer,
                        TransactionType = "Transfer",
                        TransactionDate = DateTime.Now
                    };

                    context.Transactions.Add(transaction);
                    context.SaveChanges();

                    MessageBox.Show($"{toAccount} hesabına {amountTransfer}$ göndərildi.");
                    fromTransfertextBox.Clear();
                    toTransfertextBox.Clear();
                    amountTransfertextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Düzgün məbləğ daxil edin və ya hesablar tapılmadı.");
                }
            }
        }

    }
}
