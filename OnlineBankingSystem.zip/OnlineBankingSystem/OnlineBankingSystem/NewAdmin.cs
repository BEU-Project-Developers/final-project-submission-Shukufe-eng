﻿using OnlineBankingSystem.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineBankingSystem
{
    public partial class NewAdmin : Form
    {
        public NewAdmin()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void RegisterBtn_Click(object sender, EventArgs e)
        {
            using (var context = new BankDbContext())
            {
                string username = userTextBox.Text.Trim();
                string email = emailTextBox.Text.Trim();
                string password = passwordTextBox.Text.Trim();

                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Formu Doldurun!!!");
                    return;
                }
                UserRole role = (UserRole)Enum.Parse(typeof(UserRole), comboBoxRole.SelectedItem.ToString());
                bool userExists = context.Users.Any(u => u.Username == username || u.Email == email);
                if (userExists)
                {
                    MessageBox.Show("Bu istifadəçi adı və ya e-poçt artıq mövcuddur!");
                    return;
                }

                var user = new User
                {
                    Username = username,
                    Email = email,
                    Password = password,
                    Role = role
                };
                context.Users.Add(user);
                context.SaveChanges();
                MessageBox.Show("Qeydiyyat uğurla tamamlandı!");
                userTextBox.Clear();
                emailTextBox.Clear();
                passwordTextBox.Clear();
                LoadAdmin();
                LoadAdminsDataGridView();
            }
        }
        private void LoadRoles()
        {
            comboBoxRole.Items.Clear();
            comboBoxRole.Items.Add(UserRole.Admin.ToString());
            comboBoxRole.SelectedIndex = 0;
        }

        private void NewAdmin_Load(object sender, EventArgs e)
        {
            LoadAdmin();
            LoadRoles();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }




        private void deleteAdminBtn_Click(object sender, EventArgs e)
        {
            int selectedAdminId = (int)adminsComboBox.SelectedValue;

            using (var context = new BankDbContext())
            {
                var admin = context.Users.FirstOrDefault(u => u.Id == selectedAdminId);
                if (admin != null)
                {
                    context.Users.Remove(admin);
                    context.SaveChanges();
                    MessageBox.Show("Admin uğurla silindi!");
                    LoadAdmin();
                }
                else
                {
                    MessageBox.Show("Admin tapılmadı!");
                }
            }
        }
        private void LoadAdmin()
        {
            using (var context = new BankDbContext())
            {
                var users = context.Users
                    .Where(u => u.Role == UserRole.Admin)
                    .ToList();
                adminsComboBox.DataSource = users;
                adminsComboBox.DisplayMember = "Username";
                adminsComboBox.ValueMember = "Id";
            }
        }


        private void modifyBtn_Click(object sender, EventArgs e)
        {
            string updatedUsername = UserDelUpdtxtBox.Text;
            string updatedEmail = emailDelUpdtxtBox.Text;
            string updatedPassword = passwordDelUpdtxtBox.Text;

            if (string.IsNullOrEmpty(updatedUsername) || string.IsNullOrEmpty(updatedEmail) || string.IsNullOrEmpty(updatedPassword))
            {
                MessageBox.Show("Bütün sahələri doldurun!");
                return;
            }
            int selectedAdminId = (int)adminsComboBox.SelectedValue;
            using (var context = new BankDbContext())
            {
                var admin = context.Users.FirstOrDefault(u => u.Id == selectedAdminId);
                if (admin != null)
                {
                    admin.Username = updatedUsername;
                    admin.Email = updatedEmail;
                    admin.Password = updatedPassword;
                    context.SaveChanges();
                    MessageBox.Show("Admin məlumatları uğurla yeniləndi!");
                    LoadAdmin();
                    LoadAdminsDataGridView();
                }
                else
                {
                    MessageBox.Show("Admin tapılmadı!");
                }
            }
        }

        private void adminsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void LoadAdminsDataGridView()
        {
            using (var context = new BankDbContext())
            {
                var users = context.Users
                    .Where(u => u.Role == UserRole.Admin)
                    .Select(u => new
                    {
                        u.Id, u.Username, u.Email, u.Password
                    }).ToList();
                   
             adminsDataGridView.DataSource = users;
            }
        }

        private void getAllAdminsBtn_Click(object sender, EventArgs e)
        {
            LoadAdminsDataGridView();
        }
    }
}
