﻿
namespace OnlineBankingSystem
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            comboBoxRole = new ComboBox();
            label2 = new Label();
            label3 = new Label();
            emailTextBox = new TextBox();
            passwordTextBox = new TextBox();
            loginBtn = new Button();
            registerBtn = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Green;
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(1, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(284, 449);
            panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.BankIcon;
            pictureBox1.Location = new Point(11, 105);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(252, 225);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(352, 20);
            label1.Name = "label1";
            label1.Size = new Size(362, 41);
            label1.TabIndex = 1;
            label1.Text = "Bank Managment Sytem";
            label1.Click += label1_Click;
            // 
            // comboBoxRole
            // 
            comboBoxRole.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBoxRole.ForeColor = Color.Green;
            comboBoxRole.FormattingEnabled = true;
            comboBoxRole.ImeMode = ImeMode.NoControl;
            comboBoxRole.Location = new Point(352, 105);
            comboBoxRole.Name = "comboBoxRole";
            comboBoxRole.Size = new Size(362, 39);
            comboBoxRole.TabIndex = 2;
            comboBoxRole.Text = "Role";
            comboBoxRole.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label2.Location = new Point(352, 160);
            label2.Name = "label2";
            label2.Size = new Size(75, 31);
            label2.TabIndex = 3;
            label2.Text = "Email";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label3.Location = new Point(352, 256);
            label3.Name = "label3";
            label3.Size = new Size(116, 31);
            label3.TabIndex = 4;
            label3.Text = "Password";
            label3.Click += label3_Click;
            // 
            // emailTextBox
            // 
            emailTextBox.BorderStyle = BorderStyle.FixedSingle;
            emailTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailTextBox.ForeColor = Color.Green;
            emailTextBox.Location = new Point(352, 204);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.Size = new Size(362, 38);
            emailTextBox.TabIndex = 5;
            // 
            // passwordTextBox
            // 
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            passwordTextBox.ForeColor = Color.Green;
            passwordTextBox.Location = new Point(352, 305);
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.Size = new Size(362, 38);
            passwordTextBox.TabIndex = 6;
            passwordTextBox.UseSystemPasswordChar = true;
            // 
            // loginBtn
            // 
            loginBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loginBtn.Location = new Point(352, 375);
            loginBtn.Name = "loginBtn";
            loginBtn.Size = new Size(154, 47);
            loginBtn.TabIndex = 7;
            loginBtn.Text = "Login";
            loginBtn.UseVisualStyleBackColor = true;
            loginBtn.Click += loginBtn_Click;
            // 
            // registerBtn
            // 
            registerBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registerBtn.Location = new Point(553, 375);
            registerBtn.Name = "registerBtn";
            registerBtn.Size = new Size(161, 47);
            registerBtn.TabIndex = 8;
            registerBtn.Text = "Sign Up";
            registerBtn.UseVisualStyleBackColor = true;
            registerBtn.Click += registerBtn_Click;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(800, 450);
            Controls.Add(registerBtn);
            Controls.Add(loginBtn);
            Controls.Add(passwordTextBox);
            Controls.Add(emailTextBox);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(comboBoxRole);
            Controls.Add(label1);
            Controls.Add(panel1);
            ForeColor = Color.Green;
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LoginForm";
            Load += LoginForm_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

      

    

        private void registerBtn_Click(object sender, EventArgs e)
        {
            Registration registration = new Registration();
            registration.Show();
            this.Hide();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private Label label1;
        private ComboBox comboBoxRole;
        private Label label2;
        private Label label3;
        private TextBox emailTextBox;
        private TextBox passwordTextBox;
        public Button loginBtn;
        public Button registerBtn;
        private Button button1;
    }
}