﻿using Microsoft.EntityFrameworkCore;
using OnlineBankingSystem.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineBankingSystem
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void RegisterBtn_Click(object sender, EventArgs e)
        {
            using (var context = new BankDbContext())
            {
                string username = userTextBox.Text.Trim();
                string email = emailTextBox.Text.Trim();
                string password = passwordTextBox.Text.Trim();
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Formu Doldurun!!!");
                    return;
                }
                bool userExists = context.Users.Any(u => u.Username == username || u.Email == email);
                if (userExists)
                {
                    MessageBox.Show("Bu istifadəçi adı və ya e-poçt artıq mövcuddur!");
                    return;
                }
                var user = new User
                {
                    Username = username,
                    Email = email,
                    Password = password,
                    Role = UserRole.Customer 
                };
                context.Users.Add(user);
                context.SaveChanges();
                MessageBox.Show("Qeydiyyat uğurla tamamlandı!");
                userTextBox.Clear();
                emailTextBox.Clear();
                passwordTextBox.Clear();
            }
        }

        private void Registration_Load(object sender, EventArgs e)
        {
            comboBoxRole.Items.Clear();
            comboBoxRole.Items.Add(UserRole.Customer);
            comboBoxRole.SelectedIndex = 0;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }


    }
}
