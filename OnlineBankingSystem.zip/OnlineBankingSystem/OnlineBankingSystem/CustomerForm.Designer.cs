﻿namespace OnlineBankingSystem
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            comboBoxAccounts = new ComboBox();
            balanceLabel = new Label();
            label3 = new Label();
            checkBtn = new Button();
            label2 = new Label();
            groupBox2 = new GroupBox();
            label6 = new Label();
            label5 = new Label();
            withDrawBtn = new Button();
            withdrawAmounttextBox = new TextBox();
            withDrawAccountNumbertextBox = new TextBox();
            label4 = new Label();
            groupBox3 = new GroupBox();
            label7 = new Label();
            label8 = new Label();
            DepositBtn = new Button();
            depositAmounttextBox = new TextBox();
            depositAccountNumbertextBox = new TextBox();
            label9 = new Label();
            label1 = new Label();
            groupBox4 = new GroupBox();
            label13 = new Label();
            transferBtn = new Button();
            amountTransfertextBox = new TextBox();
            label11 = new Label();
            label12 = new Label();
            toTransfertextBox = new TextBox();
            fromTransfertextBox = new TextBox();
            label10 = new Label();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.Control;
            groupBox1.Controls.Add(comboBoxAccounts);
            groupBox1.Controls.Add(balanceLabel);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(checkBtn);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(86, 53);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1094, 125);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Enter += groupBox1_Enter;
            // 
            // comboBoxAccounts
            // 
            comboBoxAccounts.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBoxAccounts.ForeColor = Color.Green;
            comboBoxAccounts.FormattingEnabled = true;
            comboBoxAccounts.Location = new Point(37, 61);
            comboBoxAccounts.Name = "comboBoxAccounts";
            comboBoxAccounts.Size = new Size(192, 36);
            comboBoxAccounts.TabIndex = 5;
            // 
            // balanceLabel
            // 
            balanceLabel.AutoSize = true;
            balanceLabel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            balanceLabel.ForeColor = Color.Green;
            balanceLabel.Location = new Point(789, 23);
            balanceLabel.Name = "balanceLabel";
            balanceLabel.Size = new Size(36, 28);
            balanceLabel.TabIndex = 4;
            balanceLabel.Text = "0$";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Green;
            label3.Location = new Point(562, 29);
            label3.Name = "label3";
            label3.Size = new Size(115, 23);
            label3.TabIndex = 3;
            label3.Text = "Your Balance";
            // 
            // checkBtn
            // 
            checkBtn.BackColor = Color.Green;
            checkBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBtn.ForeColor = Color.White;
            checkBtn.Location = new Point(297, 57);
            checkBtn.Name = "checkBtn";
            checkBtn.Size = new Size(140, 43);
            checkBtn.TabIndex = 2;
            checkBtn.Text = "Check";
            checkBtn.UseVisualStyleBackColor = false;
            checkBtn.Click += checkBtn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Green;
            label2.Location = new Point(37, 29);
            label2.Name = "label2";
            label2.Size = new Size(168, 23);
            label2.TabIndex = 0;
            label2.Text = "Check Your Balance";
            label2.Click += label2_Click;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.Control;
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(withDrawBtn);
            groupBox2.Controls.Add(withdrawAmounttextBox);
            groupBox2.Controls.Add(withDrawAccountNumbertextBox);
            groupBox2.Controls.Add(label4);
            groupBox2.ForeColor = SystemColors.InfoText;
            groupBox2.Location = new Point(86, 189);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(443, 310);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Green;
            label6.Location = new Point(6, 170);
            label6.Name = "label6";
            label6.Size = new Size(73, 23);
            label6.TabIndex = 5;
            label6.Text = "Amount";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Green;
            label5.Location = new Point(6, 90);
            label5.Name = "label5";
            label5.Size = new Size(144, 23);
            label5.TabIndex = 4;
            label5.Text = "Account Number";
            // 
            // withDrawBtn
            // 
            withDrawBtn.BackColor = Color.Green;
            withDrawBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            withDrawBtn.ForeColor = Color.White;
            withDrawBtn.Location = new Point(211, 239);
            withDrawBtn.Name = "withDrawBtn";
            withDrawBtn.Size = new Size(140, 43);
            withDrawBtn.TabIndex = 3;
            withDrawBtn.Text = "WithDraw";
            withDrawBtn.UseVisualStyleBackColor = false;
            withDrawBtn.Click += withDrawBtn_Click;
            // 
            // withdrawAmounttextBox
            // 
            withdrawAmounttextBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            withdrawAmounttextBox.ForeColor = Color.Green;
            withdrawAmounttextBox.Location = new Point(211, 159);
            withdrawAmounttextBox.Name = "withdrawAmounttextBox";
            withdrawAmounttextBox.Size = new Size(220, 34);
            withdrawAmounttextBox.TabIndex = 2;
            // 
            // withDrawAccountNumbertextBox
            // 
            withDrawAccountNumbertextBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            withDrawAccountNumbertextBox.ForeColor = Color.Green;
            withDrawAccountNumbertextBox.Location = new Point(211, 90);
            withDrawAccountNumbertextBox.Name = "withDrawAccountNumbertextBox";
            withDrawAccountNumbertextBox.Size = new Size(220, 34);
            withDrawAccountNumbertextBox.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(192, 192, 0);
            label4.Location = new Point(0, 14);
            label4.Name = "label4";
            label4.Size = new Size(150, 38);
            label4.TabIndex = 0;
            label4.Text = "WithDraw";
            // 
            // groupBox3
            // 
            groupBox3.BackColor = SystemColors.Control;
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(DepositBtn);
            groupBox3.Controls.Add(depositAmounttextBox);
            groupBox3.Controls.Add(depositAccountNumbertextBox);
            groupBox3.Controls.Add(label9);
            groupBox3.Location = new Point(716, 189);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(464, 310);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Green;
            label7.Location = new Point(23, 170);
            label7.Name = "label7";
            label7.Size = new Size(73, 23);
            label7.TabIndex = 11;
            label7.Text = "Amount";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Green;
            label8.Location = new Point(23, 90);
            label8.Name = "label8";
            label8.Size = new Size(144, 23);
            label8.TabIndex = 10;
            label8.Text = "Account Number";
            // 
            // DepositBtn
            // 
            DepositBtn.BackColor = Color.Green;
            DepositBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DepositBtn.ForeColor = Color.White;
            DepositBtn.Location = new Point(228, 239);
            DepositBtn.Name = "DepositBtn";
            DepositBtn.Size = new Size(140, 43);
            DepositBtn.TabIndex = 9;
            DepositBtn.Text = "Deposit";
            DepositBtn.UseVisualStyleBackColor = false;
            DepositBtn.Click += DepositBtn_Click;
            // 
            // depositAmounttextBox
            // 
            depositAmounttextBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            depositAmounttextBox.ForeColor = Color.Green;
            depositAmounttextBox.Location = new Point(228, 159);
            depositAmounttextBox.Name = "depositAmounttextBox";
            depositAmounttextBox.Size = new Size(220, 34);
            depositAmounttextBox.TabIndex = 8;
            // 
            // depositAccountNumbertextBox
            // 
            depositAccountNumbertextBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            depositAccountNumbertextBox.ForeColor = Color.Green;
            depositAccountNumbertextBox.Location = new Point(228, 90);
            depositAccountNumbertextBox.Name = "depositAccountNumbertextBox";
            depositAccountNumbertextBox.Size = new Size(220, 34);
            depositAccountNumbertextBox.TabIndex = 7;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(192, 192, 0);
            label9.Location = new Point(17, 14);
            label9.Name = "label9";
            label9.Size = new Size(118, 38);
            label9.TabIndex = 6;
            label9.Text = "Deposit";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(560, 9);
            label1.Name = "label1";
            label1.Size = new Size(231, 41);
            label1.TabIndex = 3;
            label1.Text = "TRANSACTION";
            // 
            // groupBox4
            // 
            groupBox4.BackColor = SystemColors.Control;
            groupBox4.Controls.Add(label13);
            groupBox4.Controls.Add(transferBtn);
            groupBox4.Controls.Add(amountTransfertextBox);
            groupBox4.Controls.Add(label11);
            groupBox4.Controls.Add(label12);
            groupBox4.Controls.Add(toTransfertextBox);
            groupBox4.Controls.Add(fromTransfertextBox);
            groupBox4.Controls.Add(label10);
            groupBox4.Location = new Point(86, 505);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(1094, 203);
            groupBox4.TabIndex = 4;
            groupBox4.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.Green;
            label13.Location = new Point(679, 76);
            label13.Name = "label13";
            label13.Size = new Size(73, 23);
            label13.TabIndex = 14;
            label13.Text = "Amount";
            // 
            // transferBtn
            // 
            transferBtn.BackColor = Color.Green;
            transferBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            transferBtn.ForeColor = Color.White;
            transferBtn.Location = new Point(858, 145);
            transferBtn.Name = "transferBtn";
            transferBtn.Size = new Size(140, 43);
            transferBtn.TabIndex = 13;
            transferBtn.Text = "Transfer";
            transferBtn.UseVisualStyleBackColor = false;
            transferBtn.Click += transferBtn_Click;
            // 
            // amountTransfertextBox
            // 
            amountTransfertextBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            amountTransfertextBox.ForeColor = Color.Green;
            amountTransfertextBox.Location = new Point(858, 65);
            amountTransfertextBox.Name = "amountTransfertextBox";
            amountTransfertextBox.Size = new Size(220, 34);
            amountTransfertextBox.TabIndex = 12;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Green;
            label11.Location = new Point(20, 140);
            label11.Name = "label11";
            label11.Size = new Size(30, 23);
            label11.TabIndex = 9;
            label11.Text = "To";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Green;
            label12.Location = new Point(20, 76);
            label12.Name = "label12";
            label12.Size = new Size(51, 23);
            label12.TabIndex = 8;
            label12.Text = "From";
            // 
            // toTransfertextBox
            // 
            toTransfertextBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            toTransfertextBox.ForeColor = Color.Green;
            toTransfertextBox.Location = new Point(223, 140);
            toTransfertextBox.Name = "toTransfertextBox";
            toTransfertextBox.Size = new Size(220, 34);
            toTransfertextBox.TabIndex = 7;
            // 
            // fromTransfertextBox
            // 
            fromTransfertextBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            fromTransfertextBox.ForeColor = Color.Green;
            fromTransfertextBox.Location = new Point(223, 76);
            fromTransfertextBox.Name = "fromTransfertextBox";
            fromTransfertextBox.Size = new Size(220, 34);
            fromTransfertextBox.TabIndex = 6;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(192, 192, 0);
            label10.Location = new Point(6, 14);
            label10.Name = "label10";
            label10.Size = new Size(123, 38);
            label10.TabIndex = 1;
            label10.Text = "Transfer";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.LoginIconn;
            pictureBox1.Location = new Point(1253, 58);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(107, 95);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // CustomerForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1413, 720);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox4);
            Controls.Add(label1);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "CustomerForm";
            Text = "CustomerForm";
            Load += CustomerForm_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Label label1;
        private Label label2;
        private Button checkBtn;
        private Label label3;
        private Label balanceLabel;
        private Label label4;
        private Label label6;
        private Label label5;
        private Button withDrawBtn;
        private TextBox withdrawAmounttextBox;
        private TextBox withDrawAccountNumbertextBox;
        private Label label7;
        private Label label8;
        private Button DepositBtn;
        private TextBox depositAmounttextBox;
        private TextBox depositAccountNumbertextBox;
        private Label label9;
        private GroupBox groupBox4;
        private Label label13;
        private Button transferBtn;
        private TextBox amountTransfertextBox;
        private Label label11;
        private Label label12;
        private TextBox toTransfertextBox;
        private TextBox fromTransfertextBox;
        private Label label10;
        private PictureBox pictureBox1;
        private ComboBox comboBoxAccounts;
    }
}