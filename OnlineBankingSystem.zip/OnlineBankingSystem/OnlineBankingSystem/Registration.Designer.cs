﻿namespace OnlineBankingSystem
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            groupBox1 = new GroupBox();
            pictureBox2 = new PictureBox();
            emailTextBox = new TextBox();
            label1 = new Label();
            RegisterBtn = new Button();
            passwordTextBox = new TextBox();
            userTextBox = new TextBox();
            label3 = new Label();
            label2 = new Label();
            comboBoxRole = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Honeydew;
            pictureBox1.Image = Properties.Resources.add_friend_icon_9;
            pictureBox1.Location = new Point(182, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(232, 220);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ControlLightLight;
            groupBox1.Controls.Add(pictureBox2);
            groupBox1.Controls.Add(emailTextBox);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(RegisterBtn);
            groupBox1.Controls.Add(passwordTextBox);
            groupBox1.Controls.Add(userTextBox);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(comboBoxRole);
            groupBox1.Location = new Point(-7, 228);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(624, 367);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Enter += groupBox1_Enter;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.LoginIconn;
            pictureBox2.Location = new Point(514, 288);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(70, 68);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // emailTextBox
            // 
            emailTextBox.BorderStyle = BorderStyle.FixedSingle;
            emailTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailTextBox.ForeColor = Color.Green;
            emailTextBox.Location = new Point(162, 173);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.Size = new Size(279, 38);
            emailTextBox.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(162, 139);
            label1.Name = "label1";
            label1.Size = new Size(75, 31);
            label1.TabIndex = 16;
            label1.Text = "Email";
            // 
            // RegisterBtn
            // 
            RegisterBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RegisterBtn.ForeColor = Color.Green;
            RegisterBtn.Location = new Point(162, 309);
            RegisterBtn.Name = "RegisterBtn";
            RegisterBtn.Size = new Size(279, 47);
            RegisterBtn.TabIndex = 14;
            RegisterBtn.Text = "Register";
            RegisterBtn.UseVisualStyleBackColor = true;
            RegisterBtn.Click += RegisterBtn_Click;
            // 
            // passwordTextBox
            // 
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            passwordTextBox.ForeColor = Color.Green;
            passwordTextBox.Location = new Point(162, 248);
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.Size = new Size(279, 38);
            passwordTextBox.TabIndex = 13;
            passwordTextBox.UseSystemPasswordChar = true;
            // 
            // userTextBox
            // 
            userTextBox.BorderStyle = BorderStyle.FixedSingle;
            userTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            userTextBox.ForeColor = Color.Green;
            userTextBox.Location = new Point(162, 98);
            userTextBox.Name = "userTextBox";
            userTextBox.Size = new Size(279, 38);
            userTextBox.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label3.ForeColor = Color.Green;
            label3.Location = new Point(162, 214);
            label3.Name = "label3";
            label3.Size = new Size(116, 31);
            label3.TabIndex = 11;
            label3.Text = "Password";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label2.ForeColor = Color.Green;
            label2.Location = new Point(162, 64);
            label2.Name = "label2";
            label2.Size = new Size(127, 31);
            label2.TabIndex = 10;
            label2.Text = "UserName";
            label2.Click += label2_Click;
            // 
            // comboBoxRole
            // 
            comboBoxRole.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBoxRole.ForeColor = Color.Green;
            comboBoxRole.FormattingEnabled = true;
            comboBoxRole.ImeMode = ImeMode.NoControl;
            comboBoxRole.Items.AddRange(new object[] { "Customer" });
            comboBoxRole.Location = new Point(162, 22);
            comboBoxRole.Name = "comboBoxRole";
            comboBoxRole.Size = new Size(279, 39);
            comboBoxRole.TabIndex = 9;
            comboBoxRole.Text = "Role";
            // 
            // Registration
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Chartreuse;
            ClientSize = new Size(609, 596);
            Controls.Add(groupBox1);
            Controls.Add(pictureBox1);
            Name = "Registration";
            Text = "Registration";
            Load += Registration_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private GroupBox groupBox1;
        public Button RegisterBtn;
        private TextBox passwordTextBox;
        private TextBox userTextBox;
        private Label label3;
        private Label label2;
        private ComboBox comboBoxRole;
        private TextBox emailTextBox;
        private Label label1;
        private PictureBox pictureBox2;
    }
}