﻿namespace OnlineBankingSystem
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewAccounts = new DataGridView();
            groupBox1 = new GroupBox();
            label2 = new Label();
            deleteBtn = new Button();
            editBtn = new Button();
            addUserAccountbtn = new Button();
            getAllUserAccountbtn = new Button();
            accountNumbertextBox = new TextBox();
            label1 = new Label();
            comboBoxUsers = new ComboBox();
            pictureBox1 = new PictureBox();
            groupBox2 = new GroupBox();
            button1 = new Button();
            label4 = new Label();
            btnSearch = new Button();
            transactionAccountNumbertextBox = new TextBox();
            label3 = new Label();
            transactionsDataGridView = new DataGridView();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAccounts).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)transactionsDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewAccounts
            // 
            dataGridViewAccounts.AllowUserToOrderColumns = true;
            dataGridViewAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewAccounts.BackgroundColor = SystemColors.GradientActiveCaption;
            dataGridViewAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAccounts.GridColor = SystemColors.HotTrack;
            dataGridViewAccounts.Location = new Point(0, 377);
            dataGridViewAccounts.Name = "dataGridViewAccounts";
            dataGridViewAccounts.RowHeadersWidth = 51;
            dataGridViewAccounts.Size = new Size(594, 233);
            dataGridViewAccounts.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonHighlight;
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(deleteBtn);
            groupBox1.Controls.Add(editBtn);
            groupBox1.Controls.Add(addUserAccountbtn);
            groupBox1.Controls.Add(getAllUserAccountbtn);
            groupBox1.Controls.Add(accountNumbertextBox);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(comboBoxUsers);
            groupBox1.Controls.Add(dataGridViewAccounts);
            groupBox1.Location = new Point(24, 83);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(594, 616);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Teal;
            label2.Location = new Point(179, 35);
            label2.Name = "label2";
            label2.Size = new Size(190, 38);
            label2.TabIndex = 8;
            label2.Text = "User Account";
            label2.Click += label2_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.Red;
            deleteBtn.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            deleteBtn.ForeColor = SystemColors.ButtonHighlight;
            deleteBtn.Location = new Point(443, 314);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(129, 57);
            deleteBtn.TabIndex = 7;
            deleteBtn.Text = "DELETE";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // editBtn
            // 
            editBtn.BackColor = Color.FromArgb(192, 192, 0);
            editBtn.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            editBtn.ForeColor = SystemColors.ButtonHighlight;
            editBtn.Location = new Point(297, 314);
            editBtn.Name = "editBtn";
            editBtn.Size = new Size(129, 57);
            editBtn.TabIndex = 6;
            editBtn.Text = "EDIT";
            editBtn.UseVisualStyleBackColor = false;
            editBtn.Click += button2_Click;
            // 
            // addUserAccountbtn
            // 
            addUserAccountbtn.BackColor = Color.Green;
            addUserAccountbtn.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            addUserAccountbtn.ForeColor = SystemColors.ButtonHighlight;
            addUserAccountbtn.Location = new Point(145, 314);
            addUserAccountbtn.Name = "addUserAccountbtn";
            addUserAccountbtn.Size = new Size(129, 57);
            addUserAccountbtn.TabIndex = 5;
            addUserAccountbtn.Text = "ADD";
            addUserAccountbtn.UseVisualStyleBackColor = false;
            addUserAccountbtn.Click += addUserAccountbtn_Click;
            // 
            // getAllUserAccountbtn
            // 
            getAllUserAccountbtn.BackColor = Color.Blue;
            getAllUserAccountbtn.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            getAllUserAccountbtn.ForeColor = SystemColors.ButtonHighlight;
            getAllUserAccountbtn.Location = new Point(0, 314);
            getAllUserAccountbtn.Name = "getAllUserAccountbtn";
            getAllUserAccountbtn.Size = new Size(129, 57);
            getAllUserAccountbtn.TabIndex = 4;
            getAllUserAccountbtn.Text = "GET";
            getAllUserAccountbtn.UseVisualStyleBackColor = false;
            getAllUserAccountbtn.Click += getAllUserAccountbtn_Click;
            // 
            // accountNumbertextBox
            // 
            accountNumbertextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            accountNumbertextBox.ForeColor = Color.Green;
            accountNumbertextBox.Location = new Point(19, 243);
            accountNumbertextBox.Name = "accountNumbertextBox";
            accountNumbertextBox.Size = new Size(333, 38);
            accountNumbertextBox.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(19, 180);
            label1.Name = "label1";
            label1.Size = new Size(196, 31);
            label1.TabIndex = 2;
            label1.Text = "Account Number";
            // 
            // comboBoxUsers
            // 
            comboBoxUsers.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            comboBoxUsers.ForeColor = Color.Green;
            comboBoxUsers.FormattingEnabled = true;
            comboBoxUsers.Location = new Point(19, 113);
            comboBoxUsers.Name = "comboBoxUsers";
            comboBoxUsers.Size = new Size(333, 39);
            comboBoxUsers.TabIndex = 1;
            comboBoxUsers.Text = "Choose User";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Control;
            pictureBox1.Image = Properties.Resources.LoginIconn;
            pictureBox1.Location = new Point(1329, 6);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(69, 71);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.ControlLightLight;
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(btnSearch);
            groupBox2.Controls.Add(transactionAccountNumbertextBox);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(transactionsDataGridView);
            groupBox2.Location = new Point(678, 83);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(695, 616);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(381, 314);
            button1.Name = "button1";
            button1.Size = new Size(166, 57);
            button1.TabIndex = 10;
            button1.Text = "GET ALL";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Teal;
            label4.Location = new Point(258, 35);
            label4.Name = "label4";
            label4.Size = new Size(185, 38);
            label4.TabIndex = 9;
            label4.Text = "Transactions";
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.Blue;
            btnSearch.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSearch.ForeColor = SystemColors.ButtonHighlight;
            btnSearch.Location = new Point(381, 156);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(166, 47);
            btnSearch.TabIndex = 6;
            btnSearch.Text = "SEARCH";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // transactionAccountNumbertextBox
            // 
            transactionAccountNumbertextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            transactionAccountNumbertextBox.ForeColor = Color.Green;
            transactionAccountNumbertextBox.Location = new Point(25, 161);
            transactionAccountNumbertextBox.Name = "transactionAccountNumbertextBox";
            transactionAccountNumbertextBox.Size = new Size(312, 38);
            transactionAccountNumbertextBox.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Green;
            label3.Location = new Point(25, 113);
            label3.Name = "label3";
            label3.Size = new Size(196, 31);
            label3.TabIndex = 4;
            label3.Text = "Account Number";
            // 
            // transactionsDataGridView
            // 
            transactionsDataGridView.AllowUserToOrderColumns = true;
            transactionsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            transactionsDataGridView.BackgroundColor = SystemColors.GradientActiveCaption;
            transactionsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            transactionsDataGridView.GridColor = SystemColors.HotTrack;
            transactionsDataGridView.Location = new Point(0, 377);
            transactionsDataGridView.Name = "transactionsDataGridView";
            transactionsDataGridView.RowHeadersWidth = 51;
            transactionsDataGridView.Size = new Size(695, 233);
            transactionsDataGridView.TabIndex = 1;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.AdminIcon1;
            pictureBox2.Location = new Point(24, 6);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(81, 80);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.InactiveBorder;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1457, 722);
            Controls.Add(pictureBox2);
            Controls.Add(groupBox2);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox1);
            Name = "AdminForm";
            Text = "AdminForm";
            Load += AdminForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewAccounts).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)transactionsDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewAccounts;
        private GroupBox groupBox1;
        private TextBox accountNumbertextBox;
        private Label label1;
        private ComboBox comboBoxUsers;
        private Button getAllUserAccountbtn;
        private Button deleteBtn;
        private Button editBtn;
        private Button addUserAccountbtn;
        private Label label2;
        private PictureBox pictureBox1;
        private GroupBox groupBox2;
        private DataGridView transactionsDataGridView;
        private TextBox transactionAccountNumbertextBox;
        private Label label3;
        private Button btnSearch;
        private Label label4;
        private Button button1;
        private PictureBox pictureBox2;
    }
}