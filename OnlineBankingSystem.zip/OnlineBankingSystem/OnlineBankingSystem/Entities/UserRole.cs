﻿namespace OnlineBankingSystem.Entities
{
    public enum UserRole { Admin, Customer }
}
