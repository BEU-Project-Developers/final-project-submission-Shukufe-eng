﻿namespace OnlineBankingSystem
{
    partial class NewAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox2 = new PictureBox();
            emailTextBox = new TextBox();
            label1 = new Label();
            RegisterBtn = new Button();
            passwordTextBox = new TextBox();
            userTextBox = new TextBox();
            label3 = new Label();
            label2 = new Label();
            comboBoxRole = new ComboBox();
            label4 = new Label();
            groupBox1 = new GroupBox();
            adminsDataGridView = new DataGridView();
            groupBox2 = new GroupBox();
            deleteAdminBtn = new Button();
            adminsComboBox = new ComboBox();
            UserDelUpdtxtBox = new TextBox();
            label5 = new Label();
            modifyBtn = new Button();
            label6 = new Label();
            passwordDelUpdtxtBox = new TextBox();
            label7 = new Label();
            label8 = new Label();
            emailDelUpdtxtBox = new TextBox();
            getAllAdminsBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)adminsDataGridView).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.LoginIconn;
            pictureBox2.Location = new Point(1323, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(62, 58);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 18;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // emailTextBox
            // 
            emailTextBox.BorderStyle = BorderStyle.FixedSingle;
            emailTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailTextBox.ForeColor = Color.Green;
            emailTextBox.Location = new Point(73, 258);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.Size = new Size(279, 38);
            emailTextBox.TabIndex = 26;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(73, 224);
            label1.Name = "label1";
            label1.Size = new Size(75, 31);
            label1.TabIndex = 25;
            label1.Text = "Email";
            // 
            // RegisterBtn
            // 
            RegisterBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RegisterBtn.ForeColor = Color.Green;
            RegisterBtn.Location = new Point(73, 394);
            RegisterBtn.Name = "RegisterBtn";
            RegisterBtn.Size = new Size(279, 47);
            RegisterBtn.TabIndex = 24;
            RegisterBtn.Text = "Register";
            RegisterBtn.UseVisualStyleBackColor = true;
            RegisterBtn.Click += RegisterBtn_Click;
            // 
            // passwordTextBox
            // 
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            passwordTextBox.ForeColor = Color.Green;
            passwordTextBox.Location = new Point(73, 333);
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.Size = new Size(279, 38);
            passwordTextBox.TabIndex = 23;
            passwordTextBox.UseSystemPasswordChar = true;
            // 
            // userTextBox
            // 
            userTextBox.BorderStyle = BorderStyle.FixedSingle;
            userTextBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            userTextBox.ForeColor = Color.Green;
            userTextBox.Location = new Point(73, 183);
            userTextBox.Name = "userTextBox";
            userTextBox.Size = new Size(279, 38);
            userTextBox.TabIndex = 22;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label3.ForeColor = Color.Green;
            label3.Location = new Point(73, 299);
            label3.Name = "label3";
            label3.Size = new Size(116, 31);
            label3.TabIndex = 21;
            label3.Text = "Password";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label2.ForeColor = Color.Green;
            label2.Location = new Point(73, 149);
            label2.Name = "label2";
            label2.Size = new Size(127, 31);
            label2.TabIndex = 20;
            label2.Text = "UserName";
            // 
            // comboBoxRole
            // 
            comboBoxRole.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBoxRole.ForeColor = Color.Green;
            comboBoxRole.FormattingEnabled = true;
            comboBoxRole.ImeMode = ImeMode.NoControl;
            comboBoxRole.Location = new Point(73, 107);
            comboBoxRole.Name = "comboBoxRole";
            comboBoxRole.Size = new Size(279, 39);
            comboBoxRole.TabIndex = 19;
            comboBoxRole.Text = "Role";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Green;
            label4.Location = new Point(63, 39);
            label4.Name = "label4";
            label4.Size = new Size(348, 50);
            label4.TabIndex = 27;
            label4.Text = "Create New Admin";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.GradientActiveCaption;
            groupBox1.Controls.Add(comboBoxRole);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(emailTextBox);
            groupBox1.Controls.Add(userTextBox);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(passwordTextBox);
            groupBox1.Controls.Add(RegisterBtn);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(453, 458);
            groupBox1.TabIndex = 28;
            groupBox1.TabStop = false;
            // 
            // adminsDataGridView
            // 
            adminsDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            adminsDataGridView.BackgroundColor = SystemColors.Control;
            adminsDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            adminsDataGridView.Dock = DockStyle.Bottom;
            adminsDataGridView.GridColor = SystemColors.MenuHighlight;
            adminsDataGridView.Location = new Point(0, 476);
            adminsDataGridView.Name = "adminsDataGridView";
            adminsDataGridView.RowHeadersWidth = 51;
            adminsDataGridView.Size = new Size(1397, 291);
            adminsDataGridView.TabIndex = 29;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.Info;
            groupBox2.Controls.Add(deleteAdminBtn);
            groupBox2.Controls.Add(adminsComboBox);
            groupBox2.Controls.Add(UserDelUpdtxtBox);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(modifyBtn);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(passwordDelUpdtxtBox);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(emailDelUpdtxtBox);
            groupBox2.Location = new Point(649, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(560, 458);
            groupBox2.TabIndex = 30;
            groupBox2.TabStop = false;
            // 
            // deleteAdminBtn
            // 
            deleteAdminBtn.BackColor = Color.FromArgb(192, 0, 0);
            deleteAdminBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            deleteAdminBtn.ForeColor = Color.Ivory;
            deleteAdminBtn.Location = new Point(412, 86);
            deleteAdminBtn.Name = "deleteAdminBtn";
            deleteAdminBtn.Size = new Size(133, 43);
            deleteAdminBtn.TabIndex = 28;
            deleteAdminBtn.Text = "Delete";
            deleteAdminBtn.UseVisualStyleBackColor = false;
            deleteAdminBtn.Click += deleteAdminBtn_Click;
            // 
            // adminsComboBox
            // 
            adminsComboBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            adminsComboBox.ForeColor = Color.Green;
            adminsComboBox.FormattingEnabled = true;
            adminsComboBox.ImeMode = ImeMode.NoControl;
            adminsComboBox.Location = new Point(119, 90);
            adminsComboBox.Name = "adminsComboBox";
            adminsComboBox.Size = new Size(279, 39);
            adminsComboBox.TabIndex = 28;
            adminsComboBox.Text = "Admins";
            adminsComboBox.SelectedIndexChanged += adminsComboBox_SelectedIndexChanged;
            // 
            // UserDelUpdtxtBox
            // 
            UserDelUpdtxtBox.BorderStyle = BorderStyle.FixedSingle;
            UserDelUpdtxtBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            UserDelUpdtxtBox.ForeColor = Color.Green;
            UserDelUpdtxtBox.Location = new Point(119, 166);
            UserDelUpdtxtBox.Name = "UserDelUpdtxtBox";
            UserDelUpdtxtBox.Size = new Size(279, 38);
            UserDelUpdtxtBox.TabIndex = 31;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Green;
            label5.Location = new Point(109, 22);
            label5.Name = "label5";
            label5.Size = new Size(315, 50);
            label5.TabIndex = 36;
            label5.Text = "Delete or Update";
            label5.Click += label5_Click;
            // 
            // modifyBtn
            // 
            modifyBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            modifyBtn.ForeColor = Color.Green;
            modifyBtn.Location = new Point(119, 377);
            modifyBtn.Name = "modifyBtn";
            modifyBtn.Size = new Size(279, 47);
            modifyBtn.TabIndex = 33;
            modifyBtn.Text = "Modify";
            modifyBtn.UseVisualStyleBackColor = true;
            modifyBtn.Click += modifyBtn_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label6.ForeColor = Color.Green;
            label6.Location = new Point(119, 132);
            label6.Name = "label6";
            label6.Size = new Size(127, 31);
            label6.TabIndex = 29;
            label6.Text = "UserName";
            // 
            // passwordDelUpdtxtBox
            // 
            passwordDelUpdtxtBox.BorderStyle = BorderStyle.FixedSingle;
            passwordDelUpdtxtBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            passwordDelUpdtxtBox.ForeColor = Color.Green;
            passwordDelUpdtxtBox.Location = new Point(119, 316);
            passwordDelUpdtxtBox.Name = "passwordDelUpdtxtBox";
            passwordDelUpdtxtBox.Size = new Size(279, 38);
            passwordDelUpdtxtBox.TabIndex = 32;
            passwordDelUpdtxtBox.UseSystemPasswordChar = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label7.ForeColor = Color.Green;
            label7.Location = new Point(119, 282);
            label7.Name = "label7";
            label7.Size = new Size(116, 31);
            label7.TabIndex = 30;
            label7.Text = "Password";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label8.ForeColor = Color.Green;
            label8.Location = new Point(119, 207);
            label8.Name = "label8";
            label8.Size = new Size(75, 31);
            label8.TabIndex = 34;
            label8.Text = "Email";
            // 
            // emailDelUpdtxtBox
            // 
            emailDelUpdtxtBox.BorderStyle = BorderStyle.FixedSingle;
            emailDelUpdtxtBox.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailDelUpdtxtBox.ForeColor = Color.Green;
            emailDelUpdtxtBox.Location = new Point(119, 241);
            emailDelUpdtxtBox.Name = "emailDelUpdtxtBox";
            emailDelUpdtxtBox.Size = new Size(279, 38);
            emailDelUpdtxtBox.TabIndex = 35;
            // 
            // getAllAdminsBtn
            // 
            getAllAdminsBtn.BackColor = Color.Blue;
            getAllAdminsBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            getAllAdminsBtn.ForeColor = Color.Ivory;
            getAllAdminsBtn.Location = new Point(1221, 406);
            getAllAdminsBtn.Name = "getAllAdminsBtn";
            getAllAdminsBtn.Size = new Size(176, 64);
            getAllAdminsBtn.TabIndex = 37;
            getAllAdminsBtn.Text = "GetAllAdmins";
            getAllAdminsBtn.UseVisualStyleBackColor = false;
            getAllAdminsBtn.Click += getAllAdminsBtn_Click;
            // 
            // NewAdmin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(1397, 767);
            Controls.Add(getAllAdminsBtn);
            Controls.Add(groupBox2);
            Controls.Add(adminsDataGridView);
            Controls.Add(groupBox1);
            Controls.Add(pictureBox2);
            Name = "NewAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NewAdmin";
            Load += NewAdmin_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)adminsDataGridView).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox2;
        private TextBox emailTextBox;
        private Label label1;
        public Button RegisterBtn;
        private TextBox passwordTextBox;
        private TextBox userTextBox;
        private Label label3;
        private Label label2;
        private ComboBox comboBoxRole;
        private Label label4;
        private GroupBox groupBox1;
        private DataGridView adminsDataGridView;
        private GroupBox groupBox2;
        private ComboBox adminsComboBox;
        private TextBox UserDelUpdtxtBox;
        private Label label5;
        public Button modifyBtn;
        private Label label6;
        private TextBox passwordDelUpdtxtBox;
        private Label label7;
        private Label label8;
        private TextBox emailDelUpdtxtBox;
        public Button deleteAdminBtn;
        public Button getAllAdminsBtn;
    }
}