﻿using OnlineBankingSystem.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineBankingSystem
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (comboBoxUsers.SelectedValue == null)
            {
                MessageBox.Show("Zəhmət olmasa user seçin!");
                return;
            }
            int accountNumber = int.Parse(accountNumbertextBox.Text);
            int userId = (int)comboBoxUsers.SelectedValue;

            using (var context = new BankDbContext())
            {
                var account = context.UserAccounts
                    .FirstOrDefault(a => a.UserId == userId);

                if (account != null)
                {
                    account.AccountNumber = accountNumber;
                    context.SaveChanges();
                    MessageBox.Show("Account Number uğurla deyisdirildi!");
                    LoadAccounts();
                }
                else
                {
                    MessageBox.Show("Bu AccountNumber və istifadəçi üçün hesab tapılmadı!");
                }
            }
        }
        private void LoadAccounts()
        {
            using (var context = new BankDbContext())
            {
                var accounts = context.UserAccounts
                    .Select(a => new
                    {
                        a.AccountNumber,
                        a.User.Username,
                        a.Balance
                    })
                    .ToList();

                dataGridViewAccounts.DataSource = accounts;
            }
        }

        private void LoadTransactionHistory()
        {
            using (var context = new BankDbContext())
            {
                var transactions = context.Transactions
                    .Select(t => new
                    {
                        t.AccountNumber,
                        t.TransactionType,
                        t.Amount,
                        t.TransactionDate,
                        t.TargetAccountNumber
                    })
                    .ToList();

                transactionsDataGridView.DataSource = transactions;
            }
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            using (var context = new BankDbContext())
            {
                var users = context.Users
                    .Where(u => u.Role == UserRole.Customer)
                    .Select(u => new
                    {
                        u.Id,
                        u.Username
                    })
                    .ToList();

                comboBoxUsers.DataSource = users;
                comboBoxUsers.DisplayMember = "Username";
                comboBoxUsers.ValueMember = "Id";

            }
        }

        private void addUserAccountbtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(accountNumbertextBox.Text, out int accountNumber) || accountNumber <= 0)
            {
                MessageBox.Show("Zəhmət olmasa düzgün Account Number daxil edin!");
                return;
            }

            using (var context = new BankDbContext())
            {
                var existingAccount = context.UserAccounts
                    .FirstOrDefault(a => a.AccountNumber == accountNumber);

                if (existingAccount != null)
                {
                    MessageBox.Show("Bu Account Number artıq mövcuddur!");
                    return;
                }

                var newAccount = new UserAccount
                {
                    AccountNumber = accountNumber,
                    Balance = 0,
                    UserId = (int)comboBoxUsers.SelectedValue
                };

                context.UserAccounts.Add(newAccount);
                context.SaveChanges();

                MessageBox.Show("Hesab uğurla yaradıldı!");
                LoadAccounts();
            }
        }

        private void getAllUserAccountbtn_Click(object sender, EventArgs e)
        {
            LoadAccounts();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridViewAccounts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Zəhmət olmasa silmək istədiyiniz hesabı seçin!");
                return;
            }
            int accountNumber = (int)dataGridViewAccounts.SelectedRows[0].Cells["AccountNumber"].Value;

            using (var context = new BankDbContext())
            {
                var account = context.UserAccounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
                if (account != null)
                {
                    context.UserAccounts.Remove(account);
                    context.SaveChanges();
                    MessageBox.Show("Hesab uğurla silindi!");
                    LoadAccounts();
                }
                else
                {
                    MessageBox.Show("Hesab tapılmadı!");
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            int accountNumber;

            if (int.TryParse(transactionAccountNumbertextBox.Text, out accountNumber))
            {
                using (var context = new BankDbContext())
                {
                    var transactions = context.Transactions
                        .Where(t => t.AccountNumber == accountNumber || t.TargetAccountNumber == accountNumber)
                        .Select(t => new
                        {
                            t.Id,
                            t.AccountNumber,
                            t.Amount,
                            t.TransactionType,
                            t.TransactionDate,
                            t.TargetAccountNumber
                        })
                        .ToList();

                    if (transactions.Any())
                    {
                        transactionsDataGridView.DataSource = transactions;
                    }
                    else
                    {
                        MessageBox.Show("Hesab nömrəsinə uyğun əməliyyat tapılmadı.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Zəhmət olmasa düzgün hesab nömrəsi daxil edin.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadTransactionHistory();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewAdmin newAdmin = new NewAdmin();
            newAdmin.Show();
        }
    }
}
